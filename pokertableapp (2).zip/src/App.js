import React, { useState, useEffect } from "react";
import "./index.css"; // Import CSS for styling

// Initial player template
const initialPlayers = Array(8)
  .fill(null)
  .map((_, i) => ({
    name: `Player ${i + 1}`,
    stack: 1000,
    bounty: 0,
    lastAction: "",
    actionHistory: [],
    holeCards: [
      { rank: "", suit: "" },
      { rank: "", suit: "" },
    ],
  }));

const suitColors = {
  "♥": "text-red-500",
  "♦": "text-blue-500",
  "♠": "text-black",
  "♣": "text-green-600",
};

// Card selector component
const CardSelector = ({ card, onChange }) => {
  const ranks = [
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "10",
    "J",
    "Q",
    "K",
    "A",
  ];
  const suits = ["♠", "♥", "♦", "♣"];
  return (
    <div className="flex gap-1 items-center">
      <select
        value={card.rank}
        onChange={(e) => onChange({ ...card, rank: e.target.value })}
        className="p-1 border rounded"
      >
        <option value="">Rank</option>
        {ranks.map((r) => (
          <option key={r} value={r}>
            {r}
          </option>
        ))}
      </select>
      <select
        value={card.suit}
        onChange={(e) => onChange({ ...card, suit: e.target.value })}
        className={`p-1 border rounded ${suitColors[card.suit] || ""}`}
      >
        <option value="">Suit</option>
        {suits.map((s) => (
          <option key={s} value={s}>
            {s}
          </option>
        ))}
      </select>
    </div>
  );
};

const PokerTableApp = () => {
  const [tables, setTables] = useState(() =>
    Array(8)
      .fill(null)
      .map(() => ({
        players: JSON.parse(JSON.stringify(initialPlayers)),
        communityCards: Array(5).fill({ rank: "", suit: "" }),
        dealerPosition: 0,
        currentPot: 1000,
      }))
  );

  const [currentTable, setCurrentTable] = useState(1);
  const table = tables[currentTable - 1];

  const [totalPlayers, setTotalPlayers] = useState(
    () => Number(localStorage.getItem("totalPlayers")) || 500
  );
  const [remainingPlayers, setRemainingPlayers] = useState(
    () => Number(localStorage.getItem("remainingPlayers")) || 500
  );
  const [numPaid, setNumPaid] = useState(
    () => Number(localStorage.getItem("numPaid")) || 50
  );
  const [minPayout, setMinPayout] = useState(
    () => Number(localStorage.getItem("minPayout")) || 100
  );
  const [customRaise, setCustomRaise] = useState("");

  useEffect(() => {
    localStorage.setItem("tables", JSON.stringify(tables));
    localStorage.setItem("totalPlayers", totalPlayers);
    localStorage.setItem("remainingPlayers", remainingPlayers);
    localStorage.setItem("numPaid", numPaid);
    localStorage.setItem("minPayout", minPayout);
  }, [tables, totalPlayers, remainingPlayers, numPaid, minPayout]);

  const updatePlayer = (index, data) => {
    const newTables = [...tables];
    newTables[currentTable - 1].players[index] = {
      ...newTables[currentTable - 1].players[index],
      ...data,
    };
    setTables(newTables);
  };

  const updateCommunityCard = (idx, newCard) => {
    const newTables = [...tables];
    const cc = [...newTables[currentTable - 1].communityCards];
    cc[idx] = newCard;
    newTables[currentTable - 1].communityCards = cc;
    setTables(newTables);
  };

  const moveDealer = () => {
    const newTables = [...tables];
    newTables[currentTable - 1].dealerPosition =
      (newTables[currentTable - 1].dealerPosition + 1) % 8;
    setTables(newTables);
  };

  const switchTable = (num) => setCurrentTable(num);

  const handleRaise = (amount) => {
    updatePlayer(0, {
      lastAction: `Raise ${amount}`,
      actionHistory: [...table.players[0].actionHistory, `Raise ${amount}`],
    });
  };

  const handleAllIn = () => {
    const heroStack = table.players[0].stack;
    updatePlayer(0, {
      lastAction: `All-In ${heroStack}`,
      actionHistory: [...table.players[0].actionHistory, `All-In ${heroStack}`],
      stack: 0,
    });
  };

  const getAdvice = () => {
    const hero = table.players[0];
    const opponents = table.players.slice(1);
    let advice = "Call";
    let exploitScore = 0;

    opponents.forEach((p) => {
      const actions = p.actionHistory.slice(-5);
      const folds = actions.filter((a) => a.includes("Fold")).length;
      const raises = actions.filter((a) => a.includes("Raise")).length;
      if (folds >= 3) exploitScore += 1;
      if (raises >= 3) exploitScore -= 1;
      if (p.stack < hero.stack * 0.5) exploitScore += 0.5;
      if (p.bounty > 0) exploitScore += 0.5;
    });

    const bubbleDistance = remainingPlayers - numPaid;
    if (bubbleDistance <= 10) exploitScore -= 1;

    if (exploitScore >= 1) advice = "Raise / Aggressive";
    if (exploitScore <= -1) advice = "Fold / Tight";

    return advice;
  };

  const handleAdvice = () => alert(`Advice: ${getAdvice()}`);

  return (
    <div className="p-4 max-w-7xl mx-auto">
      {/* Table switch */}
      <div className="flex gap-2 mb-4 flex-wrap">
        {tables.map((_, i) => (
          <button
            key={i}
            className={`px-3 py-1 rounded ${
              currentTable === i + 1 ? "bg-green-500 text-white" : "bg-gray-300"
            }`}
            onClick={() => switchTable(i + 1)}
          >
            Table {i + 1}
          </button>
        ))}
      </div>

      {/* Tournament info */}
      <div className="flex gap-4 mb-4 flex-wrap">
        <div>
          Total Players:{" "}
          <input
            type="number"
            value={totalPlayers}
            onChange={(e) => setTotalPlayers(Number(e.target.value))}
            className="w-20 p-1 border rounded"
          />
        </div>
        <div>
          Remaining:{" "}
          <input
            type="number"
            value={remainingPlayers}
            onChange={(e) => setRemainingPlayers(Number(e.target.value))}
            className="w-20 p-1 border rounded"
          />
        </div>
        <div>
          Players Paid:{" "}
          <input
            type="number"
            value={numPaid}
            onChange={(e) => setNumPaid(Number(e.target.value))}
            className="w-20 p-1 border rounded"
          />
        </div>
        <div>
          Min Payout:{" "}
          <input
            type="number"
            value={minPayout}
            onChange={(e) => setMinPayout(Number(e.target.value))}
            className="w-20 p-1 border rounded"
          />
        </div>
      </div>

      {/* Dealer */}
      <div className="flex gap-2 mb-4 items-center">
        <span>Dealer/Button Seat:</span>
        <select
          value={table.dealerPosition + 1}
          onChange={(e) => {
            const newTables = [...tables];
            newTables[currentTable - 1].dealerPosition =
              Number(e.target.value) - 1;
            setTables(newTables);
          }}
          className="p-1 border rounded"
        >
          {table.players.map((_, i) => (
            <option key={i} value={i + 1}>
              Seat {i + 1} ({table.players[i].name})
            </option>
          ))}
        </select>
        <button
          onClick={moveDealer}
          className="px-3 py-1 bg-blue-500 text-white rounded"
        >
          Move Dealer
        </button>
      </div>

      {/* Pot & actions */}
      <div className="flex gap-2 mb-4 flex-wrap items-center">
        <span>Pot:</span>
        <input
          type="number"
          value={table.currentPot}
          onChange={(e) => {
            const newTables = [...tables];
            newTables[currentTable - 1].currentPot = Number(e.target.value);
            setTables(newTables);
          }}
          className="w-20 p-1 border rounded"
        />
        <button
          onClick={() => handleRaise(table.currentPot)}
          className="px-3 py-1 bg-yellow-500 text-white rounded"
        >
          Pot Raise
        </button>
        <button
          onClick={() => handleRaise(table.currentPot / 2)}
          className="px-3 py-1 bg-purple-500 text-white rounded"
        >
          Half Pot
        </button>
        <input
          type="number"
          placeholder="Custom"
          value={customRaise}
          onChange={(e) => setCustomRaise(e.target.value)}
          className="w-20 p-1 border rounded"
        />
        <button
          onClick={() => handleRaise(Number(customRaise))}
          className="px-3 py-1 bg-indigo-500 text-white rounded"
        >
          Raise
        </button>
        <button
          onClick={handleAllIn}
          className="px-3 py-1 bg-red-500 text-white rounded"
        >
          All-In
        </button>
        <button
          onClick={handleAdvice}
          className="px-3 py-1 bg-green-700 text-white rounded"
        >
          Get Advice
        </button>
      </div>

      {/* Player Table */}
      <table className="w-full table-auto border-collapse border border-gray-400">
        <thead>
          <tr>
            <th className="border border-gray-400 p-1">Seat</th>
            <th className="border border-gray-400 p-1">Name</th>
            <th className="border border-gray-400 p-1">Stack</th>
            <th className="border border-gray-400 p-1">Bounty</th>
            <th className="border border-gray-400 p-1">Last Action</th>
            <th className="border border-gray-400 p-1">Hole Cards</th>
          </tr>
        </thead>
        <tbody>
          {table.players.map((player, idx) => (
            <tr key={idx} className={idx === 0 ? "bg-yellow-100" : ""}>
              <td className="border border-gray-400 p-1">{idx + 1}</td>
              <td className="border border-gray-400 p-1">
                <input
                  type="text"
                  value={player.name}
                  onChange={(e) => updatePlayer(idx, { name: e.target.value })}
                  className="p-1 border rounded w-full"
                />
              </td>
              <td className="border border-gray-400 p-1">
                <input
                  type="number"
                  value={player.stack}
                  onChange={(e) =>
                    updatePlayer(idx, { stack: Number(e.target.value) })
                  }
                  className="p-1 border rounded w-full"
                />
              </td>
              <td className="border border-gray-400 p-1">
                <input
                  type="number"
                  value={player.bounty}
                  onChange={(e) =>
                    updatePlayer(idx, { bounty: Number(e.target.value) })
                  }
                  className="p-1 border rounded w-full"
                />
              </td>
              <td className="border border-gray-400 p-1">
                {player.lastAction}
              </td>
              <td className="border border-gray-400 p-1 flex gap-1">
                {player.holeCards.map((card, cidx) => (
                  <CardSelector
                    key={cidx}
                    card={card}
                    onChange={(newCard) => {
                      const newPlayers = [...table.players];
                      newPlayers[idx].holeCards[cidx] = newCard;
                      const newTables = [...tables];
                      newTables[currentTable - 1].players = newPlayers;
                      setTables(newTables);
                    }}
                  />
                ))}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Community Cards */}
      <div className="flex gap-2 mt-4">
        {table.communityCards.map((card, idx) => (
          <CardSelector
            key={idx}
            card={card}
            onChange={(newCard) => updateCommunityCard(idx, newCard)}
          />
        ))}
      </div>
    </div>
  );
};

export default PokerTableApp;
