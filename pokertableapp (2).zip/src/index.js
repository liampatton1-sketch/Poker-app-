import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css"; // optional if you created a CSS file
import PokerTableApp from "./PokerTableApp"; // <-- correct path for your setup

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <PokerTableApp />
  </React.StrictMode>
);
